$(function() {

	// International Telephone Input
	var input = document.querySelector("#phone");
    window.intlTelInput(input, {
      utilsScript: "../../assets/plugins/telephoneinput/utils.js",
    });
});

